function overrideCss(docLang) {
    var the_link = document.createElement("link");
    if (docLang === "jajp") {
        prefix = "/ja";
    } else {
        prefix = "/en";
    }
    /* <link rel="stylesheet" type="text/css"
             href="@DOCS_DIR@/assets/css/ds-bootstrap.min-overrides.css" />
    */
    var attribute = document.createAttribute("rel");
    attribute.value = "stylesheet";
    the_link.setAttributeNode(attribute);
    attribute = document.createAttribute("type");
    attribute.value = "text/css";
    the_link.setAttributeNode(attribute);
    attribute = document.createAttribute("href");
    attribute.value = prefix + "/assets/css/ds-skin-override.css";
    the_link.setAttributeNode(attribute);
    document.getElementsByTagName("head")[0].appendChild(the_link);
}
