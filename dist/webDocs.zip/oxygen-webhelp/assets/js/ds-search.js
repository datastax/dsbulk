// moving DS JS to its own file for easy change and inclusion in templates
var stSearchKey = '';
var activeDocName = '';
var currentDocNames = new Set();
//currentDocNames.add(activeDocName);
// customRenderFunction
var searchResultsRenderFunction = function(document_type, item) {
    book = ( item['book'] == undefined ) ? '' : ' | ' + item['book'];
    description = ( item['description'] == undefined ) ? '' : item['description'];
    displayFlag = ( item['doc-name'] === activeDocName );
    out = '<div class="st-result">'
        + '<h3 class="title">'
        + '<a href="' 
        + item['url']
        + '" class="st-result">'
        + item['title'] + '</a> ' + book + '</h3><p class="st-description">'
        + description + '</p></div>';
    return out;
};
// modal overlay
var toggleOverlay = function() {
    var containerElement = document.getElementById("st-modal");
    if ( containerElement.style.display === 'none' ) {
        containerElement.style.display = 'block';
    }
    //window.location.reload(true); 
};
var inputHandlerFunction = function(event) {
    console.log("inputHandlerFunction called");
    toggleOverlay();
    return true;
};
var getDocnameToFilterBy = function() {
    return "{'page': {'doc-name': " + activeDocName + "}}";
};
var reloadResults = function() {
    $(window).hashchange();
};
var changeFilters = function(event) {
    console.log("changeFilters called");
    var apiCheckbox = document.getElementById("api-checkbox");
    var suffix = apiCheckbox.checked ? "-api" : "" ;
    var radioElements = Array.prototype.slice.call( document.getElementsByClassName('docNames') );
    for (var lmn of radioElements) {
        if ( lmn.checked ) {
            activeDocName = lmn.value + suffix;
            break;
            
        }
    }
    if ( ! currentDocNames.has(activeDocName) ) {
        console.log("changeFilters: " + activeDocName);
        currentDocNames.add(activeDocName);
        var resultsContainer = document.getElementById("st-results-container");
        var element = document.createElement("div");
        element.setAttribute("id", "st-results-container-" + activeDocName);
        resultsContainer.insertBefore(element, document.getElementById("st-results-container").childNodes[0]);
        initializeSearch(stSearchKey, activeDocName, apiCheckbox.checked);
    }
    for (let dname of currentDocNames.keys()) {
        var container = document.getElementById("st-results-container-" + dname);
        if (dname === activeDocName) {
            container.style.display = 'block';
        } else {
            container.style.display = 'none';
        }
    }
    return true;
};
var initializeSearch = function(key, docName, apiFlag = false) {
    console.log("initializeSearch called: " + docName + " " + apiFlag);
    // set up search
    activeDocName = docName;
    currentDocNames.add(docName);
    stSearchKey = key;
    var filterBy
    if ( apiFlag ) {
        if ( docName.substring(0, docName.length - 4) === 'alldse51' ) {
            filterBy = ['dseadmin51','dsesearch51','dsedev51','cql51','dseplanning','dsetrblshoot'];
        } else if ( docName.substring(0, docName.length - 4) === 'alldse50' ) {
            filterBy = ['dse50','cassandra30','cql33','dseplanning','dsetrblshoot'];
        } else if ( docName.substring(0, docName.length - 4) === 'alldse48' ) {
            filterBy = ['dse48','cassandra21','cql31','dseplanning','dsetrblshoot'];
        } else {
            filterBy = docName.substring(0, docName.length - 4);
        }
    } else {
        if ( docName === 'alldse51' ) {
            filterBy = ['dseadmin51', 'dsesearch51', 'dsedev51','cql51','dseplanning','dsetrblshoot'];
        } else if ( docName.substring(0, docName.length) === 'alldse50' ) {
            filterBy = ['dse50','cassandra30','cql33'];
        } else if ( docName.substring(0, docName.length) === 'alldse48' ) {
            filterBy = ['dse48','cassandra21', 'dsedev51','cql31'];
        } else {
            filterBy = docName;
        }
    }
    var ffields = apiFlag ? ['book','title','body','description','url','doc-name','codeblock','codeph'] : ['book','title','body','description','url','doc-name'] ;
    var sfields = apiFlag ? ['codeblock','codeph'] : ['book','title','body'] ;
    console.log({ searchFields: {'page': sfields} });
    $("#st-search-input").swiftypeSearch({
        renderFunction: searchResultsRenderFunction,
        fetchFields: {'page': ffields},
        filters: {'page': {'doc-name': filterBy}},
        searchFields: {'page': sfields},
        resultContainingElement: "#st-results-container-" + activeDocName,
        engineKey: key
    });
};

$("#stSearchForm").submit(inputHandlerFunction);


