/*
 *
 * dsInit.js 
 * DataStax init scripts
 * For calling methods that should be run on each page load.
 * Declare the JS source file in the template, then call 
 * the methods from here
 *
 */

function dsInit () {
  highlightSyntax();
  getPopupSection(); 
  createImagePopups();
  addAnnotations();
}

// highlight syntax using highlight.pack.js
function highlightSyntax() {
    $('pre:not(.results, .release-notes)').each(function(i, block) {
      hljs.highlightBlock(block);
    });
}

// Create image popups using magnific-popup.js
function createImagePopups() {
  $('.img-popup').magnificPopup({
    type:'image',
    disableOn: function() {
      var magnificPopup = $.magnificPopup.instance;
      return true;
    }
  });

  $('.open-popup-link').magnificPopup({
    type:'inline',
      midClick: true
  });

  $('.ajax-popup-link').magnificPopup({
    type: 'ajax' 
  });
}

function getPopupSection() {
  // Find all the tags with a filepath-popup class
  var filepaths = document.getElementsByClassName('filepath-popup');
  console.log('Found ' + filepaths.length + ' filepaths.');
  // Find the hidden sections
  var sections = document.getElementsByClassName('mfp-hide');
  console.log('Found mfp-hide sections: ' + sections.length);
  for (var i = 0; i < filepaths.length; ++i) {
    // get the file name minus any punctuation characters & whitespace
    var filepath = filepaths[i].innerHTML.replace(/[^a-zA-Z 0-9]+/g, '').replace(/\s+/g, '');
    console.log('Filepath is: ' + filepath);
    // get all the links with the stripped file name
    var links = document.getElementsByClassName(filepath);
    console.log('Found ' + filepath + ' links: ' + links.length);
    // loop through the hidden sections to find the one that refers to the file name
    for (var j = 0; j < sections.length; ++j) {
      section = sections[j];
      // examine the hidden section's id to see if it contains the stripped file name
      if (section.id.toLowerCase().indexOf(filepath.toLowerCase()) > - 1) {
        console.log('Found section for ' + filepath);
        for (var k = 0; k < links.length; ++k) {
          // update the link to the hidden content to trigger the popup
          links[k].href = '#' + section.id;
          console.log('Updated link to: ' + section.id);
        }
      } else {
        // no hidden sections were found based on the stripped file name
        // this shouldn't happen
        // possibly reasons for it occurring are typos, remnant hidden sections from removed content,
        // or incorrect conkeyrefs being added to the file
        console.log('No section for ' + filepath);
      }
    }
  }
}

var collapsibleSections = {
  /* Selectors for the nodes that contain an expand/collapse button. */
  "expand_buttons" : [
    /* Table caption */
    "table > caption > .wh_expand_btn",
    /* Article title */
    ".topic > .title > .wh_expand_btn",
    /* Section title */
    ".sectiontitle > .wh_expand_btn",
    /* Index terms groups */
    ".wh_term_group > .wh_first_letter > .wh_expand_btn"
  ],
  "collapse_by_default" : [
    /* sections with collapseByDefault output class */
    ".collapseOnLoad > .wh_expand_btn"
  ]
};

// Collapse the synopsis legend by default
$(document).ready(function () {
  collapseContent();
});

// collapse command legend tables
function collapseContent() {
  // find the button and siblings of the Legend table
  var buttonSpan = $('span:contains("Legend")').prev();
  var siblings = $('span:contains("Legend")').parent().siblings(':not(.wh_not_expandable)');
  // change the button to collapsed
  buttonSpan.toggleClass("expanded");
  // hide the Legend table contents
  siblings.toggle();

  /* Collapse selected nodes. */
  collapsibleSections.collapse_by_default.forEach(
    function(selector) {
      var matchedNodes =  $(document).find(selector);
      // Change the button state
      matchedNodes.toggleClass("expanded");
      // Will collapse the siblings of the parent node, excepting the ones that were marked otherwise
      var siblings = matchedNodes.parent().siblings(':not(.wh_not_expandable)');
      siblings.toggle();
    }
  );
}
// 1.2.9 annotator.js
function addAnnotations() {

  var username = readCookie("dsdocs.review.username");
  if ((!username)||(username=='null')||(username==="")) {
    var validEmail = false;
    while (!validEmail) {
      username = prompt("Enter your email address to comment on the docs: ");
      var emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      if (emailRegex.test(username)) {
        validEmail = true;
      }
    }
    
    createCookie("dsdocs.review.username", username, 365);
  }

    $("#annotate").annotator()
    .annotator('addPlugin', 'Store', {
        prefix: '/api',
        annotationData: {
        'uri': window.location.href
        }
    })
    .annotator('addPlugin', 'Permissions', {
        user: username
    });
}

function createCookie(name,value,days) {
    var expires;
    if (days) {
        var date = new Date();
        date.setTime(date.getTime()+(days*24*60*60*1000));
        expires = "; expires="+date.toGMTString();
    }
    else expires = "";
    document.cookie = name+"="+value+expires+"; path=/";
}

function readCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for(var i=0;i < ca.length;i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1,c.length);
        if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length,c.length);
    }
    return null;
}

function eraseCookie(name) {
    createCookie(name,"",-1);
}
//Screen copy to clipboard action
$('.screen').mouseover(function(){
    var item = $('<span class="copyTooltip"/>');
    if ( $(this).find('.copyTooltip').length === 0 ){
        $(this).prepend(item);

        $('.screen .copyTooltip').click(function(){
            var txt = $(this).closest(".screen").text();
            if(!txt || txt === ''){
                return;
            }
            copyTextToClipboard(txt);
        });
    }
});

$('.screen').mouseleave(function(){
    $('.copyTooltip').tooltip('hide');
    $(this).find('.copyTooltip').remove();
});
